欢迎加卡颂的微信（v：kasong555），我会：

- 每天在朋友圈分享 IT 最新八卦、资讯

- 拉你进`人类高质量前端框架交流群`和小伙伴们一起交流高端前端知识（备注：框架）

- 拉你进`程序员唠嗑群`和志同道合的小伙伴交流（备注：交流）

<img style="width: 200px;height:200px;" :src="$withBase('/img/kasong555.jpeg')" alt="30sec">
