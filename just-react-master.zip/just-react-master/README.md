# React 技术揭秘

React 从理念到源码，[开始阅读](https://react.iamkasong.com/)

从 0 实现 React18，请看[big-react](https://github.com/BetaSu/big-react)

如果想加入本书对应的`源码交流群`，和 7000+小伙伴们一起交流`React`源码，可以加我微信（kasong555），备注「揭秘」：

<img style="width: 200px;height:200px;" alt="image" src="https://github.com/BetaSu/just-react/assets/15828041/0c353ad7-d634-4782-8e56-dca78284cd60">

